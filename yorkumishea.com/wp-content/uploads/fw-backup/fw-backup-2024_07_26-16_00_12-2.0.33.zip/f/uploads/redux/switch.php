<?php
   class Redux_Customizer_Control_switch extends Redux_Customizer_Control {
     public $type = "redux-switch";
   }