<?php
   class Redux_Customizer_Control_import_export extends Redux_Customizer_Control {
     public $type = "redux-import_export";
   }