<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Categories -->
<div class="entry-categories">
	<div class="category-wrap">
		<i class="dticon-folder"> </i>
		<?php the_category(', '); ?>
	</div>
</div><!-- Entry Categories -->