<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Categories -->
<div class="entry-categories"><i class="dticon-folder"> </i><?php the_category(' '); ?></div><!-- Entry Categories -->