<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Categories -->
<div class="entry-categories"><?php 
	echo esc_html__('In ', 'designthemes-theme');
	the_category(' '); ?></div><!-- Entry Categories -->