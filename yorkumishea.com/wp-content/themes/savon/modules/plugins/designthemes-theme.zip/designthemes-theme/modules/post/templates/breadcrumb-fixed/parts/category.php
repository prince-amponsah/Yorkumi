<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Categories -->
<div class="entry-categories"><div class="category-wrap"><?php the_category(' '); ?></div></div><!-- Entry Categories -->