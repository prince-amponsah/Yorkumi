<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Tags -->
<div class="entry-tags"><?php the_tags( '<div class="tag-wrap"><span>'.esc_html__('A story about', 'designthemes-theme').'</span><p>', ' ', '</p></div>' ); ?></div><!-- Entry Tags -->